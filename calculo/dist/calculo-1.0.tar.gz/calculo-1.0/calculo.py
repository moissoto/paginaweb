def suma(n1:int,n2:int)->int:
    n3=n1+n2
    return n3