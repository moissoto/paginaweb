from setuptools import setup

setup(
    name='calculadora',
    version= '1.0',
    description = 'Calculadora en python',
    author= 'Moisés Soto Córdova',
    author_email = 'moissoto@gmail.com',
    url='www.moissoto.com',
    py_modules = ['calculadora']
)