from setuptools import setup

setup(
    name='codificador',
    version= '1.0',
    description = 'codificador/decodificador base64',
    author= 'Moisés Soto Córdova',
    author_email = 'moissoto@gmail.com',
    url='www.moissoto.com',
    py_modules = ['codificador']
)